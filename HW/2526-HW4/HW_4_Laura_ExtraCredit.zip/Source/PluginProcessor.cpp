/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
_2526HW4AudioProcessor::_2526HW4AudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
     : AudioProcessor (BusesProperties()
                     #if ! JucePlugin_IsMidiEffect
                      #if ! JucePlugin_IsSynth
                       .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      #endif
                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                     #endif
                       ),
#endif
    apvts(*this, nullptr, "Parameters", createParams())
{
}

_2526HW4AudioProcessor::~_2526HW4AudioProcessor()
{
}

juce::AudioProcessorValueTreeState::ParameterLayout
    _2526HW4AudioProcessor::createParams()
{
    return {
        std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{"delay", 1}, "Delay length", 0.0, 2, 0.25),
        std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{"mix", 1}, "Mix", 0.0f, 1.0f, 0.5f),
        std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{"feedback", 1}, "Feedback", 0.0f, 0.95f, 0.3f)
    };
}


//==============================================================================
const juce::String _2526HW4AudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool _2526HW4AudioProcessor::acceptsMidi() const
{
   #if JucePlugin_WantsMidiInput
    return true;
   #else
    return false;
   #endif
}

bool _2526HW4AudioProcessor::producesMidi() const
{
   #if JucePlugin_ProducesMidiOutput
    return true;
   #else
    return false;
   #endif
}

bool _2526HW4AudioProcessor::isMidiEffect() const
{
   #if JucePlugin_IsMidiEffect
    return true;
   #else
    return false;
   #endif
}

double _2526HW4AudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int _2526HW4AudioProcessor::getNumPrograms()
{
    return 1;   // NB: some hosts don't cope very well if you tell them there are 0 programs,
                // so this should be at least 1, even if you're not really implementing programs.
}

int _2526HW4AudioProcessor::getCurrentProgram()
{
    return 0;
}

void _2526HW4AudioProcessor::setCurrentProgram (int index)
{
}

const juce::String _2526HW4AudioProcessor::getProgramName (int index)
{
    return {};
}

void _2526HW4AudioProcessor::changeProgramName (int index, const juce::String& newName)
{
}

//==============================================================================
void _2526HW4AudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    // call your initializing functions and set variables here!
    samplingRate = sampleRate;
    bufferSize = samplesPerBlock;
    int maxDelay = maxDelaySec * samplingRate;
    int numChannels = getTotalNumOutputChannels();
    delay.prepare(samplingRate, maxDelay, numChannels);
}

void _2526HW4AudioProcessor::releaseResources()
{
    // When playback stops, you can use this as an opportunity to free up any
    // spare memory, etc.
}

#ifndef JucePlugin_PreferredChannelConfigurations
bool _2526HW4AudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
  #if JucePlugin_IsMidiEffect
    juce::ignoreUnused (layouts);
    return true;
  #else
    // This is the place where you check if the layout is supported.
    // In this template code we only support mono or stereo.
    // Some plugin hosts, such as certain GarageBand versions, will only
    // load plugins that support stereo bus layouts.
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    // This checks if the input layout matches the output layout
   #if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
   #endif

    return true;
  #endif
}
#endif

void _2526HW4AudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    
    juce::ScopedNoDenormals noDenormals;
    auto totalNumInputChannels  = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();
    
    int numSamples = buffer.getNumSamples();

    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear (i, 0, numSamples);
    
    // get params
    //auto* delayParam = apvts.getRawParameterValue("delay");
    float delayLengthSec = *apvts.getRawParameterValue("delay");
    float wetMix = *apvts.getRawParameterValue("mix");
    float feedback = *apvts.getRawParameterValue("feedback");

    delay.setDelayTime(delayLengthSec); // delay time to be used as samples
    delay.setFeedbackAmt(feedback);
    delay.setWetMix(wetMix);
    

    for (int channel = 0; channel < totalNumInputChannels; ++channel)
    {
        auto* channelData = buffer.getWritePointer (channel);

        for (int i = 0; i < numSamples; ++i)
        {
            // your delay function is called below. Do not change
            channelData[i] = delay.processSample(channelData[i], channel);
        }
    }
}

//==============================================================================
bool _2526HW4AudioProcessor::hasEditor() const
{
    return true; // (change this to false if you choose to not supply an editor)
}

juce::AudioProcessorEditor* _2526HW4AudioProcessor::createEditor()
{
    return new _2526HW4AudioProcessorEditor (*this);
}

//==============================================================================
void _2526HW4AudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    // You should use this method to store your parameters in the memory block.
    // You could do that either as raw data, or use the XML or ValueTree classes
    // as intermediaries to make it easy to save and load complex data.
}

void _2526HW4AudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    // You should use this method to restore your parameters from this memory block,
    // whose contents will have been created by the getStateInformation() call.
}

//==============================================================================
// This creates new instances of the plugin..
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new _2526HW4AudioProcessor();
}
